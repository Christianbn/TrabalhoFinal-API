package com.example.tf.exception;

public class DescricaoException extends RuntimeException{

}
