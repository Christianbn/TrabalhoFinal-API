package com.example.tf.DTO;

public class EnderecoDTO {

}
