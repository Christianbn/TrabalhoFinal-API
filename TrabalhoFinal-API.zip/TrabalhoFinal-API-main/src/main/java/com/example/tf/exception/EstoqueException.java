package com.example.tf.exception;

public class EstoqueException extends Exception{

}
