package com.example.tf.exception;

public class EmailException extends Exception{

}
