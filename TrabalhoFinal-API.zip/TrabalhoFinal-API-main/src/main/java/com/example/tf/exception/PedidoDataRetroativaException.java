package com.example.tf.exception;

public class PedidoDataRetroativaException extends Exception{

}
