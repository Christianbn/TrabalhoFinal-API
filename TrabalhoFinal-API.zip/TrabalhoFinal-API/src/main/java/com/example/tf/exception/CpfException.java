package com.example.tf.exception;

public class CpfException extends Exception{

}
