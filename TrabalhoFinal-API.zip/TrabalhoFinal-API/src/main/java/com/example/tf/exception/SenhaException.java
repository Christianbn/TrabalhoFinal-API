package com.example.tf.exception;

public class SenhaException extends RuntimeException{

}
