package com.example.tf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
